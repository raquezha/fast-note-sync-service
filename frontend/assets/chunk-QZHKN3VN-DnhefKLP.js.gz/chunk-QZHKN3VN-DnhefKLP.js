var t;import{_ as r}from"./markdown-editor-CfWAw89j.js";var i=(r(t=class{constructor(t){this.init=t,this.records=this.init()}reset(){this.records=this.init()}},"ImperativeState"),t);export{i as I};
